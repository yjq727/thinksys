---
name: viral-video-clone
description: 给对标视频/选题 → 自动复刻爆款风格，出成品竖屏视频。先分析→写稿→一键 pipeline 生产。
version: 3.0.0
author: 千寻
contact: 微信：qianxunchuhai
tags: [video, viral, clone, 竖屏, 爆款, pipeline]
---

# 爆款视频克隆

## 触发

用户给出对标视频链接/文件 + 选题主题。

## 执行流程

### 第一步：环境安装（仅首次）

```bash
python3 /home/hermes/.hermes/skills/video/viral-video-clone/scripts/pipeline.py \
  --work-dir "/home/hermes/项目文件/视频制作工厂/<项目名>/" \
  --setup
```

`--setup` 自动完成 7 项检查+安装并输出进度：
1. ffmpeg/ffprobe
2. Python 依赖 (whisper, edge-tts, dashscope, Pillow, numpy)
3. whisper
4. edge-tts
5. dashscope + PIL + numpy
6. 字体 霞鹜文楷
7. DASHSCOPE_API_KEY

全部通过后进入下一步。已安装的自动跳过。

### 第二步：准备项目目录

```bash
export WORK_DIR="/home/hermes/项目文件/视频制作工厂/<项目名>/"
mkdir -p "$WORK_DIR/audio" "$WORK_DIR/visuals/frames" "$WORK_DIR/final"
```

### 第三步：分析对标视频

提取并写入 `$WORK_DIR/analysis.md`：
- 前3秒钩子结构
- 叙事节奏（每20-30秒情绪转折点）
- 结尾CTA（评论区触发机制）
- 视觉风格（古风/现代/科技/暗调）
- 字幕风格（颜色/大小/位置/动效）
- BGM方向（史诗/紧张/温情/轻快）

### 第四步：写稿 + 定分镜

**script.md** — 完整配音文本。规则：
- 前3秒强钩子
- 每20-30秒情绪转折
- 需要高亮的关键词用 `**关键词**` 标记（自动生成金色高亮字幕）
- 结尾明确评论触发

**image_prompts.txt** — 每行一个生图prompt。

默认规则（用户可按需覆写）：
- 必须含 `vertical 9:16, atmospheric`
- 古风类加 `cinematic ancient China, gold/orange palace lighting`
- 禁止要求图中生成中文文字（字幕会覆盖）
- 避免连续同人物特写，用氛围图代替

用户自定义提示词风格时，可直接修改 `image_prompts.txt` 中的每行prompt。pipeline 只负责把每行喂给百炼，不强制修改内容。

**scenes.json** — 分镜配置。格式：
```json
{
  "project": "项目名",
  "output": "final/output.mp4",
  "resolution": {"width": 1080, "height": 1920},
  "fps": 30,
  "scenes": [
    {
      "scene_id": "hook",
      "name": "钩子开场",
      "start": 0.0,
      "end": 9.5,
      "image_files": ["visuals/frames/01.png", "visuals/frames/02.png"],
      "ken_burns_direction": "zoom_in"
    }
  ],
  "audio": {
    "voiceover": "audio/voiceover.mp3",
    "bgm": "audio/bgm.mp3",
    "bgm_volume": 0.16
  },
  "subtitles": {
    "file": "final/subtitles.ass",
    "enabled": true
  }
}
```

Ken Burns 方向：`zoom_in` / `zoom_out` / `zoom_in_slow` / `pan_right` / `pan_left`

### 第五步：一键生产

```bash
export DASHSCOPE_API_KEY="<百炼API Key>"
python3 /home/hermes/.hermes/skills/video/viral-video-clone/scripts/pipeline.py \
  --work-dir "$WORK_DIR" \
  --bgm <jade-river-journey|jade-temple-garden|journey-through-the-jade-empire>
```

pipeline.py 自动执行 6 步：
1. Edge-TTS 配音 (`zh-CN-YunjianNeural`)
2. Whisper medium 提取时间轴
3. 生成 ASS 字幕（霞鹜文楷，关键词金色高亮，≤13字/行，淡入动效）
4. 百炼 z-image-turbo 生图 + 亮度检测（<80警告）
5. FFmpeg 合成（Ken Burns + BGM混音，amix公式已验证）
6. QA 检查

**跳过步骤**（已有产出不想重跑）：
- `--skip-tts`：已有 voiceover.mp3
- `--skip-images`：已有 visuals/frames/*.png

## 已验证致命问题

1. **生图后必做亮度检测**：百炼API超时残留文件2-3MB但亮度仅27-68（正常>80），pipeline已内置检测。
2. **先配音再字幕**：用Whisper时间戳对齐，禁止字数估算时长。
3. **amix音量补偿**：FFmpeg amix把每个输入÷N，必须人声 `volume=2.0` 补偿，pipeline已内置。
4. **BGM先验证RMS**：文件可能静音但ffprobe正常，pipeline不处理此问题——如BGM异常需手动换。

## BGM库

路径：`/home/hermes/项目文件/视频制作工厂/bgm库/`

用户往此目录放入 `.mp3` 后即可通过 `--bgm <文件名(不含.mp3)>` 使用。

默认曲目：
| --bgm 参数 | 文件 | 时长 | 风格 |
|---|---|---|---|
| jade-river-journey | jade-river-journey.mp3 | 150s | 史诗古风 |
| jade-temple-garden | jade-temple-garden.mp3 | 128s | 古风悠扬 |
| journey-through-the-jade-empire | journey-through-the-jade-empire.mp3 | 64s | 激昂古风 |

---

© 千寻 | 微信：qianxunchuhai | 禁止转载商用
