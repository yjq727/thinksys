# 爱马仕（Hermes Agent）爆款视频克隆教程

> **作者：千寻 | 微信：qianxunchuhai**
>
> 本文仅作学习交流，禁止转载。

---

## 目录

1. [什么是爱马仕（Hermes Agent）](#1-什么是爱马仕hermes-agent)
2. [安装爱马仕](#2-安装爱马仕)
3. [安装视频克隆技能包](#3-安装视频克隆技能包)
4. [环境准备](#4-环境准备)
5. [开工：从对标视频到成片](#5-开工从对标视频到成片)
6. [每一步详解：AI 到底在做什么](#6-每一步详解ai-到底在做什么)
7. [BGM 选择指南](#7-bgm-选择指南)
8. [常见问题](#8-常见问题)

---

## 1. 什么是爱马仕（Hermes Agent）

爱马仕是一个运行在 Linux 服务器上的 **AI 智能助理**，它能理解自然语言指令，调用各种工具（终端命令、浏览器、Python 脚本、API 等）帮你完成复杂任务。

**它能做什么？**
- 读写文件、执行命令、安装软件
- 调用在线 API（生图、配音、语音识别）
- 跑 Python 脚本、处理音视频
- 按照预制「技能包」（Skill）中的工作流，自动执行多步骤任务

**本教程的场景：**
你给爱马仕一个对标视频，它自动模仿爆款风格，7 步出成品竖屏视频——包含脚本、配音、字幕、画面、BGM。

---

## 2. 安装爱马仕

### 2.1 环境要求

- 一台 Linux 服务器（Ubuntu / Debian 推荐，境外云服务器最佳，国内访问 GitHub 和部分 API 可能受限）
- Python 3.10+
- 一个 Telegram 账号（用于和爱马仕对话）

### 2.2 安装步骤

```bash
# 1. 安装爱马仕
curl -fsSL https://hermes-agent.nousresearch.com/install.sh | bash

# 2. 初始化配置
hermes setup

# 3. 按提示配置：
#    - 选择 AI 模型提供商（推荐 deepseek 或 openrouter）
#    - 填入 API Key
#    - 关联 Telegram（爱马仕会生成一个 Telegram Bot Token，按指引操作）
```

### 2.3 验证安装

```bash
hermes --help
```

看到帮助信息即安装成功。此时在 Telegram 上和你的 Bot 对话，爱马仕就会回应。

> **提示：** 爱马仕的能力上限取决于你选的模型。做视频需要较强的理解和执行能力，建议用 deepseek-v3 或 claude-sonnet-4 级别。

---

## 3. 安装视频克隆技能包

技能包是一个包含 `SKILL.md` 和配套脚本的文件夹，爱马仕读取后就能按固定流程执行。

### 3.1 获取技能包

从千寻处获取 `viral-video-clone` 文件夹，上传到你的服务器。

### 3.2 安装到爱马仕

```bash
# 复制到爱马仕技能目录
cp -r viral-video-clone ~/.hermes/skills/video/

# 验证技能已加载
hermes skills list | grep viral
```

爱马仕在下次对话中就会认识这个技能。

### 3.3 技能包结构一览

```
viral-video-clone/
├── SKILL.md                          # 核心工作流（AI 阅读执行）
├── setup.sh                          # 一键环境安装
├── requirements.txt                  # Python 依赖
├── scripts/
│   ├── scene_based_editor.py         # FFmpeg 场景编辑器
│   └── generate_frames_bailian.py    # 百炼批量生图
├── templates/
│   └── subtitles.ass                 # 字幕样式模板
└── bgm库/                           # 3 首古风 BGM
    ├── jade-river-journey.mp3
    ├── jade-temple-garden.mp3
    └── journey-through-the-jade-empire.mp3
```

---

## 4. 环境准备

在开始做视频之前，爱马仕需要安装一系列系统工具和 Python 包。

### 4.1 一键安装（推荐）

直接在服务器上跑技能包自带的一键脚本：

```bash
cd ~/.hermes/skills/video/viral-video-clone
bash setup.sh
```

这个脚本会自动检测并安装所有缺失依赖。

### 4.2 手动安装清单

如果一键脚本失败，逐项安装：

| 工具 | 用途 | 安装命令 |
|------|------|----------|
| ffmpeg / ffprobe | 视频编码、音频混音、字幕烧录 | `sudo apt install -y ffmpeg` |
| openai-whisper | 从配音中提取字幕时间轴 | `pip install openai-whisper` |
| edge-tts | 生成配音 | `pip install edge-tts` |
| dashscope | 调用百炼生图 API | `pip install dashscope` |
| Pillow, numpy | 图片处理、亮度检测 | `pip install Pillow numpy` |
| 霞鹜文楷字体 | ASS 字幕渲染 | 见下方 |

字体安装：
```bash
mkdir -p ~/.fonts
curl -sL "https://github.com/lxgw/LxgwWenKai/releases/download/v1.330/LXGWWenKai-Bold.ttf" \
  -o ~/.fonts/LXGWWenKai-Bold.ttf
fc-cache -f
fc-list | grep "LXGW WenKai"   # 验证
```

### 4.3 配置百炼 API Key

生图需要阿里云百炼（通义万相）的 API Key：

```bash
export DASHSCOPE_API_KEY="sk-你的key"
```

获取方式：登录 [阿里云百炼平台](https://bailian.console.aliyun.com)，开通通义万相服务，创建 API Key。

### 4.4 验证全部就绪

```bash
ffmpeg -version          # 视频编码器
whisper --help            # 语音识别
edge-tts --help           # 配音
python3 -c "import dashscope; print('OK')"   # 生图 API
fc-list | grep "LXGW WenKai"                  # 字幕字体
echo $DASHSCOPE_API_KEY                       # API Key
```

每一项都有输出才算就绪。

---

## 5. 开工：从对标视频到成片

### 第〇步：告诉爱马仕要用这个技能

在 Telegram 上发送：

> **模仿这个视频，做一个关于 xxx 的。**

同时附上对标视频的链接或截图。爱马仕会加载技能包，自动执行。

### 整个流程耗时

一个 60-90 秒的竖屏视频，完整走下来约 **20-40 分钟**，取决于生图速度和网络。大部分时间 AI 在工作，你只需要在它问你时回复。

### 你只需要做这些：

1. **发对标视频** + 一句话选题
2. **等 AI 分析完**，确认风格方向（AI 会问你）
3. **等 AI 写完脚本**，审一眼要不要改
4. **等出片**

剩下的——配音、字幕、生图、剪辑、混音——全是爱马仕自己干。

---

## 6. 每一步详解：AI 到底在做什么

下面以一个历史人物视频为例，展示爱马仕在每一步具体执行什么。

### 第 1 步：分析对标视频

**AI 做的事：**
- 观看你发的对标视频（提取封面、标题、文案）
- 分析钩子结构（前 3 秒说了什么、怎么抓人）
- 分析叙事节奏（每 20-30 秒一个情绪转折）
- 分析评论区触发点（结尾 CTA 怎么诱导评论）
- 分析视觉风格（古风/现代/科技）
- 分析字幕样式（颜色、大小、位置、动效）

**输出示例：**
```
风格分析：
- 开头：抛出一个反认知事实制造冲突
- 节奏：每25秒一个"反转"节点
- 结尾：开放式提问"你觉得 xx 是英雄还是罪人？"
- 视觉：古风氛围图 + Ken Burns 慢推
- 字幕：白色中文字幕 + 金色关键词高亮
- BGM：史诗古风
```

**你需要做什么：** 确认或调整方向。

---

### 第 2 步：写稿

**AI 做的事：**
- 参考对标的结构和节奏
- 围绕你的选题写一篇口播稿
- 前 3 秒强钩子
- 每 20-30 秒一个情绪转折
- 结尾明确的评论触发点

**对历史类题材的额外约束：**
- 不用「首创」「发明」→ 用「推动」「促成」
- 不把有争议的说法写成定论

**输出示例：**
```
公元 604 年，杨广登基。
所有人都觉得，大隋会毁在这个"暴君"手里。
但很少有人知道——他做了一件事，影响了此后一千三百年。
...
（全文约 400-600 字，对应 60-90 秒口播）
```

**你需要做什么：** 审一眼，不改就确认。

---

### 第 3 步：生成配音

**AI 做的事：**
- 用 edge-tts 生成一段**连续**配音（不分段，保证自然流畅）
- 默认音色 `zh-CN-YunjianNeural`（男声，沉稳大气）
- 保存为 `audio/voiceover.mp3`

**后台命令：**
```bash
edge-tts --voice zh-CN-YunjianNeural --text "全文" --write-media audio/voiceover.mp3
```

**验证：**
```bash
ffprobe audio/voiceover.mp3  # 检查时长
```

这一步是**整个视频的时间基准**，所有后续步骤都以此对齐。

---

### 第 4 步：Whisper 提取字幕时间轴

**AI 做的事：**
- 用 Whisper 将配音识别为文本
- 提取每个词/句的精确起止时间戳

**后台命令：**
```bash
whisper audio/voiceover.mp3 --model medium --language zh --output_format json
```

**为什么必须用 Whisper 而不是手算？**
- 中文每个字发音时长不固定
- 语气停顿、语速变化无法预估
- 字数 × 0.25 秒的估算误差累积后字幕会飞

---

### 第 5 步：生成字幕（带关键词高亮）

**AI 做的事：**
- 根据 Whisper 时间戳，生成 ASS 格式字幕文件
- 每行 ≤13 个汉字，自动断句
- 淡入动效（`\fad(400,0)`）
- 每句选 1-2 个情感关键词，用金色大字高亮

**字幕样式：**
- 字体：霞鹜文楷 Bold
- 正文：白色 68pt，描边 4px
- 关键词高亮：金色 #FFAA00，76pt bold，描边 3px
- 位置：竖屏居中偏下

**关键词选择规则：**
- 反转认知的词（"暴君"→"千古一帝"的那个瞬间）
- 核心论点
- 情感爆点
- 结尾 CTA

---

### 第 6 步：生图

**AI 做的事：**
- 根据脚本内容，为每个场景写生图提示词
- 调用百炼 z-image-turbo 批量生图（竖屏 1152×2048）
- **强制亮度检测**——部分生图虽然文件大小正常但画面全黑，必须用 PIL 测平均亮度
- 亮度 < 80 的图自动重生成

**生图提示词示例：**
```
cinematic ancient Chinese palace, golden morning light streaming through pillars,
atmospheric dust particles, vertical 9:16 composition, warm color grading
```

**注意：** 提示词不加中文文字——字幕会覆盖在画面上。

---

### 第 7 步：合成最终视频

**AI 做的事：**
- 根据分镜配置 `scenes.json`，逐场景合成：
  - 图片 + Ken Burns 运动（缩放/平移）→ 场景片段
  - 串联所有场景片段 → 完整无声视频
- 混音：配音（人声 100%）+ BGM（8%）
- 烧录 ASS 字幕
- 输出 1080×1920，30fps MP4

**音频混音公式（关键）：**
```
人声 volume=2.0 → BGM volume=0.16 → amix
```
FFmpeg 的 amix 会自动把每个输入除以输入数，所以人声必须补偿 ×2，才能保持 100% 音量。BGM 只有 8%，若有若无，不抢戏。

**运行命令：**
```bash
python3 scripts/scene_based_editor.py \
  --scenes scenes.json \
  --out final/output.mp4
```

**最终验证：**
```bash
ffprobe final/output.mp4
```
检查时长、分辨率、音视频编码是否正常。

---

## 7. BGM 选择指南

技能包自带 3 首古风 BGM：

| 文件名 | 时长 | 风格 | 适合 |
|--------|------|------|------|
| jade-river-journey.mp3 | 150s | 史诗古风，大气磅礴 | 历史正剧、战争叙事 |
| jade-temple-garden.mp3 | 128s | 古风悠扬，轻快 | 人物传记、文化科普 |
| journey-through-the-jade-empire.mp3 | 64s | 激昂古风 | 短平快爆点内容 |

**如何添加自己的 BGM：**
直接把 mp3 文件放进 `bgm库/` 目录即可，AI 自动识别。

**BGM 使用规则：**
- 混音前 AI 会采样检测 BGM 是否静音（遇到过文件正常但无声的情况）
- BGM 循环播放，以配音时长为基准截断
- 音量固定 8%，仅作背景氛围

---

## 8. 常见问题

### Q1：爱马仕推进到一半停了怎么办？

在 Telegram 上发 **"继续"** 或 **"go on"**。AI 会读取当前进度，从断点继续。

### Q2：生图太慢或失败？

- 检查 `DASHSCOPE_API_KEY` 是否过期
- 百炼 API 偶尔超时，AI 会自动检测暗图并重试
- 如果持续失败，切换到备选方案（FLUX.1 via n1n.ai）——告诉爱马仕即可

### Q3：字幕字体显示为方块？

霞鹜文楷未安装或 fc-cache 未刷新：
```bash
fc-list | grep WenKai
fc-cache -f
```

### Q4：视频有画面没声音？

检查配音文件：`ffprobe audio/voiceover.mp3`。确保 edge-tts 成功生成。

### Q5：我想换配音音色？

告诉爱马仕你要用哪个音色。edge-tts 支持的中文音色：
- `zh-CN-YunjianNeural`（男声，沉稳）—— 默认
- `zh-CN-YunxiNeural`（男声，年轻）
- `zh-CN-XiaoxiaoNeural`（女声）
- `zh-CN-XiaoyiNeural`（女声）

### Q6：一个视频大约花多少钱？

- 百炼生图：约 0.04 元/张，按 15 张图算 ≈ **0.6 元**
- 配音、Whisper：免费（本地运行）
- AI 模型调用：取决于你的 API 定价，deepseek 约 **0.1-0.3 元**

总计不到 **1 元/条**。

### Q7：能做其他风格吗？不想只做古风。

可以。第 1 步分析对标视频时，AI 会提取对标视频的风格。你只需给一个不同风格的对标视频，AI 就会模仿那个风格。

---

## 最后

这个技能包的灵魂是 **AI 对对标视频的分析和模仿能力**。你给什么样的对标，它就出什么样的风格。

有问题找千寻：微信 qianxunchuhai。

*© 千寻 | 仅供学习交流，禁止转载。*
