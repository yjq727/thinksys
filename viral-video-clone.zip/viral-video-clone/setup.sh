#!/usr/bin/env bash
# viral-video-clone 一键环境安装
# 用途：检查并安装本 skill 所需全部依赖
set -euo pipefail

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

ok()  { echo -e "${GREEN}✓${NC} $1"; }
warn(){ echo -e "${YELLOW}⚠${NC} $1"; }
fail(){ echo -e "${RED}✗${NC} $1"; }

echo "============================================"
echo " viral-video-clone 环境检测与安装"
echo "============================================"

MISSING=()

# 1. ffmpeg / ffprobe
echo ""
echo "[1/6] 检测 ffmpeg..."
if command -v ffmpeg &>/dev/null; then
    ok "ffmpeg 已安装: $(ffmpeg -version 2>&1 | head -1)"
else
    fail "ffmpeg 未安装"
    MISSING+=("ffmpeg")
fi

if command -v ffprobe &>/dev/null; then
    ok "ffprobe 已安装"
else
    fail "ffprobe 未安装"
    MISSING+=("ffprobe")
fi

# 2. whisper
echo ""
echo "[2/6] 检测 whisper..."
if python3 -c "import whisper" 2>/dev/null; then
    ok "whisper 已安装"
else
    fail "whisper 未安装"
    MISSING+=("whisper")
fi

# 3. edge-tts
echo ""
echo "[3/6] 检测 edge-tts..."
if command -v edge-tts &>/dev/null; then
    ok "edge-tts 已安装"
else
    fail "edge-tts 未安装"
    MISSING+=("edge-tts")
fi

# 4. Python 依赖
echo ""
echo "[4/6] 检测 Python 依赖..."
for pkg in dashscope PIL numpy; do
    if python3 -c "import ${pkg}" 2>/dev/null; then
        ok "${pkg}"
    else
        fail "${pkg} 未安装"
        MISSING+=("python-${pkg}")
    fi
done

# 5. 字体
echo ""
echo "[5/6] 检测霞鹜文楷字体..."
if fc-list | grep -qi "LXGW WenKai"; then
    ok "霞鹜文楷已安装"
else
    fail "霞鹜文楷未安装"
    MISSING+=("font-lxgw-wenkai")
fi

# 6. BGM 库
echo ""
echo "[6/6] 检测 BGM 库..."
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
BGM_DIR="$SCRIPT_DIR/bgm库"
if [ -d "$BGM_DIR" ] && ls "$BGM_DIR"/*.mp3 &>/dev/null; then
    ok "BGM 库: $(ls "$BGM_DIR"/*.mp3 | wc -l) 首曲目"
else
    warn "BGM 库为空或不存在（非致命，但做视频前需要音乐）"
fi

# --- 安装缺失依赖 ---
if [ ${#MISSING[@]} -eq 0 ]; then
    echo ""
    echo "============================================"
    echo -e " ${GREEN}全部依赖已就绪！${NC}"
    echo "============================================"
    exit 0
fi

echo ""
echo "============================================"
echo " 以下依赖缺失，开始安装："
echo "============================================"
printf '  - %s\n' "${MISSING[@]}"
echo ""

INSTALL_FFMPEG=false
INSTALL_PYTHON=()
INSTALL_FONT=false

for m in "${MISSING[@]}"; do
    case "$m" in
        ffmpeg|ffprobe)
            INSTALL_FFMPEG=true ;;
        whisper)
            INSTALL_PYTHON+=("openai-whisper") ;;
        edge-tts)
            INSTALL_PYTHON+=("edge-tts") ;;
        python-dashscope)
            INSTALL_PYTHON+=("dashscope") ;;
        python-PIL)
            INSTALL_PYTHON+=("Pillow") ;;
        python-numpy)
            INSTALL_PYTHON+=("numpy") ;;
        font-lxgw-wenkai)
            INSTALL_FONT=true ;;
    esac
done

if $INSTALL_FFMPEG; then
    echo "→ 安装 ffmpeg..."
    if command -v apt &>/dev/null; then
        sudo apt install -y ffmpeg
    elif command -v brew &>/dev/null; then
        brew install ffmpeg
    else
        echo "请手动安装 ffmpeg"
    fi
fi

if [ ${#INSTALL_PYTHON[@]} -gt 0 ]; then
    echo "→ 安装 Python 包: ${INSTALL_PYTHON[*]}"
    pip install "${INSTALL_PYTHON[@]}"
fi

if $INSTALL_FONT; then
    echo "→ 安装霞鹜文楷字体..."
    mkdir -p ~/.fonts
    curl -sL "https://github.com/lxgw/LxgwWenKai/releases/download/v1.330/LXGWWenKai-Bold.ttf" -o ~/.fonts/LXGWWenKai-Bold.ttf
    fc-cache -f
fi

echo ""
echo "============================================"
echo -e " ${GREEN}安装完成！请重新运行本脚本验证。${NC}"
echo "============================================"
