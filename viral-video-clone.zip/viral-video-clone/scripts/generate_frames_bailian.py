#!/usr/bin/env python3
"""Batch generate frames using Dashscope/百炼 z-image-turbo.

Usage:
  export DASHSCOPE_API_KEY="sk-xxx"
  python3 generate_frames.py --prompts prompts.txt --out visuals/frames/ --size 1152*2048

prompts.txt format: one prompt per line
"""
import argparse
import base64
import json
import os
import sys
from pathlib import Path

import dashscope
from dashscope import ImageSynthesis


def generate_image(prompt: str, size: str = "1152*2048") -> str | None:
    """Generate one image, return base64 or None."""
    rsp = ImageSynthesis.call(
        model="z-image-turbo",
        prompt=prompt,
        n=1,
        size=size,
    )
    if rsp.status_code == 200 and rsp.output.results:
        return rsp.output.results[0].b64_json
    else:
        print(f"ERROR: {rsp.message}", file=sys.stderr)
        return None


def batch_generate(prompts: list[str], out_dir: Path, size: str = "1152*2048"):
    out_dir.mkdir(parents=True, exist_ok=True)
    for i, prompt in enumerate(prompts, 1):
        print(f"[{i}/{len(prompts)}] Generating...")
        b64 = generate_image(prompt, size)
        if b64:
            path = out_dir / f"{i:02d}.png"
            with open(path, "wb") as f:
                f.write(base64.b64decode(b64))
            fsize = path.stat().st_size
            print(f"  Saved: {path} ({fsize/1024/1024:.1f}MB)")
        else:
            print(f"  FAILED")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--prompts", type=Path, required=True, help="prompts.txt, one per line")
    ap.add_argument("--out", type=Path, required=True, help="output directory")
    ap.add_argument("--size", default="1152*2048", help="image size, default 1152*2048")
    args = ap.parse_args()

    api_key = os.environ.get("DASHSCOPE_API_KEY")
    if not api_key:
        print("ERROR: DASHSCOPE_API_KEY not set", file=sys.stderr)
        sys.exit(1)

    prompts = [l.strip() for l in args.prompts.read_text().splitlines() if l.strip()]
    print(f"Generating {len(prompts)} images...")
    batch_generate(prompts, args.out, args.size)

    # Brightness audit
    print("\n=== Brightness Audit ===")
    try:
        from PIL import Image
        import numpy as np
        for f in sorted(args.out.iterdir()):
            if f.suffix == ".png":
                img = Image.open(f)
                arr = np.array(img, dtype=float)
                brightness = np.mean(arr)
                flag = " ⚠️ TOO DARK" if brightness < 80 else " ✓"
                print(f"  {f.name}: {brightness:.0f}{flag}")
    except ImportError:
        print("  PIL not available, skipping brightness check")


if __name__ == "__main__":
    main()
