#!/usr/bin/env python3
"""Viral video clone pipeline — one command from script to final video.

Usage:
  python3 pipeline.py --work-dir /path/to/project/ [--bgm jade-river-journey] [--voice zh-CN-YunjianNeural]

Input files expected in work-dir/:
  script.md           — full narration text
  image_prompts.txt   — one image prompt per line
  scenes.json         — scene configuration (see scene_based_editor.py)

Output:
  final/output.mp4    — finished vertical video with subtitles, BGM, Ken Burns
"""

import argparse
import json
import os
import re
import shlex
import subprocess
import sys
from pathlib import Path
from typing import Any

# ── Paths ──────────────────────────────────────────────
SKILL_DIR = Path(__file__).resolve().parent.parent
SCRIPTS_DIR = SKILL_DIR / "scripts"
BGM_LIB = Path("/home/hermes/项目文件/视频制作工厂/bgm库")
FONT_PATH = Path.home() / ".fonts" / "LXGWWenKai-Bold.ttf"


def run(cmd: list[str], check: bool = True, cwd: Path | None = None) -> subprocess.CompletedProcess:
    print("$", " ".join(shlex.quote(str(x)) for x in cmd))
    return subprocess.run(cmd, check=check, cwd=cwd)


def run_quiet(cmd: list[str]) -> subprocess.CompletedProcess:
    """Run command silently, capture output."""
    return subprocess.run(cmd, capture_output=True, text=True)


def check_cmd(name: str) -> bool:
    """Check if a command exists on PATH."""
    return run_quiet(["which", name]).returncode == 0


# ── Step 0: Setup ───────────────────────────────────────
def setup():
    """Install all dependencies with progress reporting."""
    total = 7
    step = 0

    def report(msg: str):
        nonlocal step
        step += 1
        print(f"[{step}/{total}] {msg}")

    print("=== 环境安装 ===\n")

    # 1. ffmpeg
    report("检查 ffmpeg/ffprobe...")
    if not check_cmd("ffmpeg") or not check_cmd("ffprobe"):
        print("  安装 ffmpeg...")
        run(["sudo", "apt-get", "install", "-y", "ffmpeg"])
    print("  ✓ ffmpeg")

    # 2. Python deps
    report("安装 Python 依赖 (whisper, edge-tts, dashscope, Pillow, numpy)...")
    run([sys.executable, "-m", "pip", "install", "-q",
         "openai-whisper", "edge-tts", "dashscope", "Pillow", "numpy"])
    print("  ✓ Python deps")

    # 3. whisper
    report("验证 whisper...")
    result = run_quiet(["whisper", "--help"])
    if result.returncode != 0:
        raise SystemExit("whisper 安装失败")
    print("  ✓ whisper")

    # 4. edge-tts
    report("验证 edge-tts...")
    result = run_quiet(["edge-tts", "--help"])
    if result.returncode != 0:
        raise SystemExit("edge-tts 安装失败")
    print("  ✓ edge-tts")

    # 5. dashscope
    report("验证 dashscope...")
    result = subprocess.run(
        [sys.executable, "-c", "import dashscope, PIL, numpy; print('OK')"],
        capture_output=True, text=True
    )
    if "OK" not in result.stdout:
        raise SystemExit("dashscope/PIL/numpy 导入失败")
    print("  ✓ dashscope + PIL + numpy")

    # 6. 字体
    report("安装字体 霞鹜文楷...")
    FONT_PATH.parent.mkdir(parents=True, exist_ok=True)
    if not FONT_PATH.exists():
        run(["curl", "-sL",
             "https://github.com/lxgw/LxgwWenKai/releases/download/v1.330/LXGWWenKai-Bold.ttf",
             "-o", str(FONT_PATH)])
        run(["fc-cache", "-f"])
    print(f"  ✓ {FONT_PATH.name}")

    # 7. API Key
    report("检查 DASHSCOPE_API_KEY...")
    if not os.environ.get("DASHSCOPE_API_KEY"):
        print("  ⚠ 未设置 DASHSCOPE_API_KEY，生图步骤将失败")
        print("  设置: export DASHSCOPE_API_KEY=\"sk-xxx\"")
    else:
        print("  ✓ DASHSCOPE_API_KEY 已设置")

    print("\n=== 安装完成 ===\n")


# ── Step 1: TTS ────────────────────────────────────────
def generate_voiceover(script_path: Path, out_path: Path, voice: str):
    """Generate continuous voiceover from script using edge-tts."""
    text = script_path.read_text(encoding="utf-8").strip()
    if not text:
        raise SystemExit("script.md is empty")
    
    out_path.parent.mkdir(parents=True, exist_ok=True)
    # edge-tts can't handle very long text; write to temp file
    tmp_text = out_path.parent / "_tts_input.txt"
    tmp_text.write_text(text, encoding="utf-8")
    
    run([
        "edge-tts", "--voice", voice,
        "-f", str(tmp_text),
        "--write-media", str(out_path)
    ])
    tmp_text.unlink(missing_ok=True)
    
    # Verify
    result = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration",
         "-of", "json", str(out_path)],
        capture_output=True, text=True
    )
    duration = float(json.loads(result.stdout)["format"]["duration"])
    print(f"Voiceover: {out_path} ({duration:.1f}s)")


# ── Step 2: Whisper ─────────────────────────────────────
def whisper_transcribe(audio_path: Path, out_dir: Path):
    """Extract timestamps from voiceover using whisper."""
    out_dir.mkdir(parents=True, exist_ok=True)
    run([
        "whisper", str(audio_path),
        "--model", "medium",
        "--language", "zh",
        "--output_format", "json",
        "--output_dir", str(out_dir)
    ])
    # Whisper outputs audio/voiceover.json
    json_path = out_dir / f"{audio_path.stem}.json"
    if not json_path.exists():
        raise SystemExit(f"Whisper output not found: {json_path}")
    return json_path


# ── Step 3: ASS Subtitles ───────────────────────────────
def generate_ass(
    script_path: Path,
    whisper_json: Path,
    out_path: Path,
):
    """Generate ASS subtitles with keyword highlighting from whisper timestamps.
    
    Keywords in script.md marked with **keyword** get HL style (gold highlight).
    Lines auto-split to ≤13 Chinese characters.
    """
    script_text = script_path.read_text(encoding="utf-8").strip()
    segments = json.loads(whisper_json.read_text())["segments"]
    
    out_path.parent.mkdir(parents=True, exist_ok=True)
    
    ass = []
    ass.append("""[Script Info]
Title: Viral Video Clone
ScriptType: v4.00+
PlayResX: 1080
PlayResY: 1920

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,LXGW WenKai,68,&H00FFFFFF,&H000000FF,&H00000000,&H00000000,-1,0,0,0,100,100,3,0,1,4,2,5,20,20,0,1
Style: HL,LXGW WenKai Bold,76,&H0000AAFF,&H000000FF,&H00000000,&H00000000,-1,0,0,0,100,100,3,0,1,4,3,5,20,20,0,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
""")
    
    def split_subtitle_lines(text: str, max_chars: int = 13) -> list[str]:
        """Split text into subtitle lines, keeping natural breaks."""
        # Remove keyword markers for length calculation
        clean = re.sub(r'\*\*', '', text)
        if len(clean) <= max_chars:
            return [text]
        
        lines = []
        remaining = text
        while remaining:
            clean_remaining = re.sub(r'\*\*', '', remaining)
            if len(clean_remaining) <= max_chars:
                lines.append(remaining)
                break
            # Split at max_chars, try to break at punctuation
            chunk = remaining[:max_chars + 5]  # look a bit ahead
            # Find last punctuation or space
            for sep in ['，', '。', '！', '？', '、', ' ', '的', '了']:
                idx = chunk.rfind(sep)
                if idx > 3 and idx <= max_chars:
                    lines.append(remaining[:idx + 1])
                    remaining = remaining[idx + 1:]
                    break
            else:
                lines.append(remaining[:max_chars])
                remaining = remaining[max_chars:]
        return lines
    
    def format_ass_text(text: str) -> str:
        """Convert **keyword** to {\\rHL}keyword{\\rDefault}."""
        return re.sub(r'\*\*(.+?)\*\*', r'{\\rHL}\\1{\\rDefault}', text)
    
    def format_time(seconds: float) -> str:
        h = int(seconds // 3600)
        m = int((seconds % 3600) // 60)
        s = seconds % 60
        return f"{h}:{m:02d}:{s:05.2f}"
    
    for seg in segments:
        seg_text = seg["text"].strip()
        if not seg_text:
            continue
        
        start = seg["start"]
        end = seg["end"]
        duration = end - start
        
        lines = split_subtitle_lines(seg_text)
        per_line = duration / len(lines)
        
        for i, line in enumerate(lines):
            line_start = start + i * per_line
            line_end = start + (i + 1) * per_line
            ass_text = format_ass_text(line)
            ass.append(
                f"Dialogue: 0,{format_time(line_start)},{format_time(line_end)},"
                f"Default,,0,0,0,,{{\\fad(400,0)}}{ass_text}"
            )
    
    out_path.write_text("\n".join(ass), encoding="utf-8")
    print(f"Subtitles: {out_path} ({len(segments)} segments)")


# ── Step 4: Image Generation ────────────────────────────
def generate_images(prompts_path: Path, out_dir: Path):
    """Generate images using Dashscope/百炼."""
    out_dir.mkdir(parents=True, exist_ok=True)
    run([
        sys.executable,
        str(SCRIPTS_DIR / "generate_frames_bailian.py"),
        "--prompts", str(prompts_path),
        "--out", str(out_dir),
    ])


# ── Step 5: Composite ───────────────────────────────────
def composite(scenes_path: Path, work_dir: Path):
    """Run scene_based_editor.py to produce final video."""
    out = work_dir / "final" / "output.mp4"
    out.parent.mkdir(parents=True, exist_ok=True)
    run([
        sys.executable,
        str(SCRIPTS_DIR / "scene_based_editor.py"),
        "--scenes", str(scenes_path),
        "--out", str(out),
        "--work-dir", str(work_dir / "final" / "scene_segments")
    ])


# ── Step 6: QA ──────────────────────────────────────────
def qa_check(video_path: Path):
    """Quick quality check on final video."""
    if not video_path.exists():
        raise SystemExit(f"Output not found: {video_path}")
    
    # Probe
    result = subprocess.run([
        "ffprobe", "-v", "error",
        "-show_entries", "format=duration,size:stream=index,codec_type,codec_name,width,height",
        "-of", "json", str(video_path)
    ], capture_output=True, text=True)
    info = json.loads(result.stdout)
    
    fmt = info.get("format", {})
    streams = info.get("streams", [])
    
    print(f"\n=== QA: {video_path.name} ===")
    print(f"  Size: {int(fmt.get('size', 0)) / 1024 / 1024:.1f} MB")
    print(f"  Duration: {float(fmt.get('duration', 0)):.1f}s")
    
    for s in streams:
        t = s.get("codec_type", "?")
        if t == "video":
            print(f"  Video: {s.get('width')}x{s.get('height')}, {s.get('codec_name')}, {s.get('r_frame_rate')}")
        elif t == "audio":
            print(f"  Audio: {s.get('codec_name')}, {s.get('sample_rate')}Hz")
    
    # Check video has both streams
    has_video = any(s["codec_type"] == "video" for s in streams)
    has_audio = any(s["codec_type"] == "audio" for s in streams)
    
    issues = []
    if not has_video:
        issues.append("No video stream")
    if not has_audio:
        issues.append("No audio stream")
    if fmt.get("duration") and float(fmt["duration"]) < 3:
        issues.append("Too short (<3s)")
    
    if issues:
        print(f"  ⚠️  ISSUES: {', '.join(issues)}")
    else:
        print(f"  ✓ Passed")


# ── Main ────────────────────────────────────────────────
def main():
    ap = argparse.ArgumentParser(description="Viral video clone pipeline")
    ap.add_argument("--work-dir", type=Path, required=True, help="Project directory")
    ap.add_argument("--bgm", type=str, default="jade-river-journey", help="BGM filename from library")
    ap.add_argument("--voice", type=str, default="zh-CN-YunjianNeural", help="Edge-TTS voice")
    ap.add_argument("--skip-tts", action="store_true", help="Skip TTS if voiceover exists")
    ap.add_argument("--skip-images", action="store_true", help="Skip image gen if frames exist")
    ap.add_argument("--setup", action="store_true", help="Auto-install dependencies before running")
    args = ap.parse_args()
    
    # ── Setup (if requested) ──
    if args.setup:
        setup()
    
    wd = args.work_dir.resolve()
    print(f"Pipeline start: {wd}")
    
    # Verify inputs
    required = ["script.md", "image_prompts.txt", "scenes.json"]
    for f in required:
        if not (wd / f).exists():
            raise SystemExit(f"Missing required file: {wd / f}")
    
    # Verify deps
    for cmd in ["ffmpeg", "ffprobe", "whisper", "edge-tts"]:
        if subprocess.run(["which", cmd], capture_output=True).returncode != 0:
            raise SystemExit(f"Missing dependency: {cmd}")
    
    # Verify font
    if not FONT_PATH.exists():
        raise SystemExit(f"Font not installed: {FONT_PATH}\n"
                         f"Install: curl -sL https://github.com/lxgw/LxgwWenKai/releases/download/v1.330/LXGWWenKai-Bold.ttf -o {FONT_PATH} && fc-cache -f")
    
    # Verify API key
    if not os.environ.get("DASHSCOPE_API_KEY"):
        raise SystemExit("DASHSCOPE_API_KEY not set")
    
    # BGM
    bgm_src = BGM_LIB / args.bgm if (BGM_LIB / args.bgm).exists() else BGM_LIB / f"{args.bgm}.mp3"
    if not bgm_src.exists():
        raise SystemExit(f"BGM not found: {bgm_src}\nAvailable: {list(BGM_LIB.glob('*.mp3'))}")
    
    import shutil
    bgm_dst = wd / "audio" / "bgm.mp3"
    bgm_dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(bgm_src, bgm_dst)
    print(f"BGM: {bgm_src.name}")
    
    # ── Step 1: TTS ──
    voiceover_path = wd / "audio" / "voiceover.mp3"
    if args.skip_tts and voiceover_path.exists():
        print(f"Skip TTS, using existing: {voiceover_path}")
    else:
        print("\n── Step 1/6: Generating voiceover ──")
        generate_voiceover(wd / "script.md", voiceover_path, args.voice)
    
    # ── Step 2: Whisper ──
    print("\n── Step 2/6: Extracting timestamps (whisper) ──")
    whisper_json = whisper_transcribe(voiceover_path, wd / "audio")
    
    # ── Step 3: ASS Subtitles ──
    print("\n── Step 3/6: Generating subtitles ──")
    generate_ass(wd / "script.md", whisper_json, wd / "final" / "subtitles.ass")
    
    # ── Step 4: Image Generation ──
    frames_dir = wd / "visuals" / "frames"
    if args.skip_images and frames_dir.exists() and list(frames_dir.glob("*.png")):
        print(f"\n── Step 4/6: Skipping image gen (frames exist) ──")
    else:
        print("\n── Step 4/6: Generating images ──")
        generate_images(wd / "image_prompts.txt", frames_dir)
    
    # ── Step 5: Composite ──
    print("\n── Step 5/6: Compositing video ──")
    composite(wd / "scenes.json", wd)
    
    # ── Step 6: QA ──
    print("\n── Step 6/6: Quality check ──")
    qa_check(wd / "final" / "output.mp3" if not (wd / "final" / "output.mp4").exists() else wd / "final" / "output.mp4")
    
    print(f"\n✓ Done: {wd / 'final' / 'output.mp4'}")


if __name__ == "__main__":
    main()
