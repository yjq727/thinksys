#!/usr/bin/env python3
"""Scene-based video editor - JSON-driven FFmpeg pipeline.

Reads a scene list JSON, generates per-scene video segments with Ken Burns
zoompan on images, then concatenates all scenes, muxes voiceover + BGM,
and burns ASS subtitles.

Usage:
  python3 tools/scene_based_editor.py \
    --scenes scenes.json \
    --out final/output.mp4

Required JSON schema:
  {
    "project": "name",
    "output": "final/output.mp4",
    "resolution": {"width": 1080, "height": 1920},
    "fps": 30,
    "scenes": [
      {
        "scene_id": "hook",
        "start": 0.0, "end": 9.5,
        "image_files": ["visuals/frames/01.png"],
        "ken_burns_direction": "zoom_in"
      }
    ],
    "audio": {
      "voiceover": "audio/voiceover.mp3",
      "bgm": "audio/bgm.mp3",
      "bgm_volume": 0.16
    },
    "subtitles": {
      "file": "final/subtitles.ass",
      "enabled": true
    }
  }

Audio mix formula (proven):
  voice:volume=2.0 → bgm:volume=0.16 → amix=inputs=2
  Result: voice 100%, BGM ~8% (amix divides each input by N)
"""
from __future__ import annotations

import argparse
import json
import math
import shlex
import subprocess
import sys
from pathlib import Path
from typing import Any

IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".webp"}


def run(cmd: list[str], check: bool = True) -> subprocess.CompletedProcess:
    print("$", " ".join(shlex.quote(x) for x in cmd))
    return subprocess.run(cmd, check=check)


def probe_duration(path: Path) -> float:
    out = subprocess.check_output([
        "ffprobe", "-v", "error",
        "-show_entries", "format=duration",
        "-of", "json", str(path)
    ], text=True)
    return float(json.loads(out)["format"]["duration"])


def resolve_path(base_dir: Path, rel: str) -> Path:
    p = Path(rel)
    if p.is_absolute():
        return p
    return (base_dir / p).resolve()


def collect_images(image_list: list[str], base_dir: Path) -> list[Path]:
    imgs = [resolve_path(base_dir, p) for p in image_list]
    missing = [p for p in imgs if not p.exists()]
    if missing:
        raise SystemExit(f"Missing images: {missing}")
    return imgs


def ken_burns_expr(direction: str, frames: int) -> str:
    """Return zoompan z= expression string for a given direction."""
    match direction:
        case "zoom_in":
            step = 0.15 / max(1, frames)
            return f"'min(zoom+{step:.6f},1.15)'"
        case "zoom_out":
            step = 0.15 / max(1, frames)
            return f"'max(zoom-{step:.6f},1.0)'"
        case "zoom_in_slow":
            step = 0.10 / max(1, frames)
            return f"'min(zoom+{step:.6f},1.10)'"
        case "pan_right":
            step = 0.12 / max(1, frames)
            return f"'min(zoom+{step:.6f},1.12)'"
        case "pan_left":
            step = 0.12 / max(1, frames)
            return f"'min(zoom+{step:.6f},1.12)'"
        case _:
            step = 0.10 / max(1, frames)
            return f"'min(zoom+{step:.6f},1.10)'"


def make_scene_segment(
    images: list[Path],
    out: Path,
    duration: float,
    direction: str,
    fps: int = 30,
) -> None:
    """Create a scene segment by concatenating images with Ken Burns motion."""
    if not images:
        raise ValueError("No images for scene segment")

    num_images = len(images)
    per_image = duration / num_images
    per_frames = max(1, math.ceil(per_image * fps))

    temp_clips: list[Path] = []
    work_dir = out.parent
    work_dir.mkdir(parents=True, exist_ok=True)

    for idx, img in enumerate(images):
        temp = work_dir / f"{out.stem}_img{idx:02d}.mp4"
        z_expr = ken_burns_expr(direction, per_frames)
        pan_x = " (iw-ow)/2 "
        pan_y = " (ih-oh)/2 "
        if direction == "pan_right":
            pan_x = f"' (iw-ow)*((zoom-1)/zoom)*{idx}/{max(1,num_images-1)} '"
        elif direction == "pan_left":
            pan_x = f"' (iw-ow)*((zoom-1)/zoom)*({max(1,num_images-1)}-{idx})/{max(1,num_images-1)} '"

        vf = (
            "scale=1080:1920:force_original_aspect_ratio=increase,"
            "crop=1080:1920,setsar=1,"
            f"zoompan=z={z_expr}:x={pan_x}:y={pan_y}:d={per_frames}:s=1080x1920:fps={fps},"
            "format=yuv420p"
        )
        run([
            "ffmpeg", "-y", "-loop", "1", "-i", str(img),
            "-t", f"{per_image:.3f}", "-vf", vf,
            "-r", str(fps), "-an", "-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
            str(temp)
        ])
        temp_clips.append(temp)

    if len(temp_clips) == 1:
        run(["cp", str(temp_clips[0]), str(out)])
    else:
        concat_txt = work_dir / f"{out.stem}_concat.txt"
        concat_txt.write_text(
            "".join(f"file '{p.resolve()}'\n" for p in temp_clips),
            encoding="utf-8"
        )
        run([
            "ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", str(concat_txt),
            "-c", "copy", str(out)
        ])

    for temp in temp_clips:
        temp.unlink(missing_ok=True)
    if len(temp_clips) > 1:
        concat_txt.unlink(missing_ok=True)


def concat_segments(segments: list[Path], out: Path) -> None:
    concat_file = out.parent / "concat_scenes.txt"
    concat_file.write_text(
        "".join(f"file '{p.resolve()}'\n" for p in segments),
        encoding="utf-8"
    )
    run([
        "ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", str(concat_file),
        "-c", "copy", str(out)
    ])


def mux_audio(
    video: Path,
    voice: Path,
    bgm: Path | None,
    bgm_volume: float,
    subtitles: Path | None,
    out: Path,
) -> None:
    inputs = ["-i", str(video), "-i", str(voice)]
    filter_parts = []
    maps = ["-map", "0:v"]

    if bgm and bgm.exists():
        inputs += ["-stream_loop", "-1", "-i", str(bgm)]
        # amix divides each input by N; boost voice to compensate
        filter_parts.append("[1:a]volume=2.0[voice]")
        filter_parts.append(f"[2:a]volume={bgm_volume}[bgm]")
        filter_parts.append("[voice][bgm]amix=inputs=2:duration=first:dropout_transition=0[aout]")
        maps += ["-map", "[aout]"]
    else:
        maps += ["-map", "1:a"]

    vf = []
    if subtitles and subtitles.exists():
        sub = str(subtitles.resolve()).replace("\\", "\\\\").replace(":", "\\:")
        vf.append(f"ass='{sub}'")

    cmd = ["ffmpeg", "-y", *inputs]
    if filter_parts:
        cmd += ["-filter_complex", ";".join(filter_parts)]
    if vf:
        cmd += ["-vf", ",".join(vf)]
    cmd += [
        *maps,
        "-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
        "-c:a", "aac", "-b:a", "192k",
        "-shortest",
        str(out)
    ]
    run(cmd)


def load_scenes(json_path: Path) -> dict[str, Any]:
    with open(json_path, "r", encoding="utf-8") as f:
        data = json.load(f)
    if "scenes" not in data:
        raise SystemExit("JSON must contain 'scenes' array")
    return data


def main() -> None:
    ap = argparse.ArgumentParser(description="Scene-based video editor")
    ap.add_argument("--scenes", required=True, type=Path, help="Path to scenes.json")
    ap.add_argument("--out", required=True, type=Path, help="Output MP4 path")
    ap.add_argument("--fps", type=int, default=30)
    ap.add_argument("--work-dir", type=Path, help="Temp working directory")
    args = ap.parse_args()

    base_dir = args.scenes.parent.resolve()
    data = load_scenes(args.scenes)

    voice_path = resolve_path(base_dir, data["audio"]["voiceover"])
    bgm_path = resolve_path(base_dir, data["audio"]["bgm"]) if data["audio"].get("bgm") else None
    bgm_volume = data["audio"].get("bgm_volume", 0.16)
    subtitles_path = None
    if data.get("subtitles", {}).get("enabled"):
        subtitles_path = resolve_path(base_dir, data["subtitles"]["file"])

    voice_duration = probe_duration(voice_path)
    print(f"Voiceover duration: {voice_duration:.3f}s")

    args.out.parent.mkdir(parents=True, exist_ok=True)
    work = args.work_dir or (args.out.parent / "scene_segments")
    work.mkdir(parents=True, exist_ok=True)

    scenes = data["scenes"]
    segments: list[Path] = []
    for i, scene in enumerate(scenes, 1):
        scene_id = scene["scene_id"]
        name = scene["name"]
        if "start" in scene and "end" in scene:
            duration = scene["end"] - scene["start"]
        else:
            duration = scene.get("estimated_duration", scene.get("duration", 5.0))
        images = collect_images(scene["image_files"], base_dir)
        direction = scene.get("ken_burns_direction", "zoom_in")

        seg_out = work / f"scene_{i:02d}_{scene_id}.mp4"
        print(f"\n[{i}/{len(scenes)}] Scene '{name}' ({scene_id}): {len(images)} images, {duration:.2f}s")
        make_scene_segment(images, seg_out, duration, direction, args.fps)
        segments.append(seg_out)

    silent_video = work / "video_no_audio_scenes.mp4"
    print("\nConcatenating scene segments...")
    concat_segments(segments, silent_video)

    print("\nMuxing audio and subtitles...")
    mux_audio(silent_video, voice_path, bgm_path, bgm_volume, subtitles_path, args.out)

    print("\nFinal output probe:")
    run([
        "ffprobe", "-v", "error",
        "-show_entries", "format=duration,size:stream=index,codec_type,codec_name,width,height,r_frame_rate",
        "-of", "json", str(args.out)
    ])
    print(f"\nDone: {args.out}")


if __name__ == "__main__":
    main()
